import Foundation

struct APIList {
    static let baseUrl = "http://localhost/planora"
    static let baseUrl1Ai = "http://127.0.0.1:8000/"
    static let baseUrlAi = "http://127.0.0.1:5000/"
    static let loginUrl = "\(baseUrl)/login.php"
    static let registerUrl = "\(baseUrl)/register.php"
    
    
    static let eventUrl = "\(baseUrl)/create_event.php"
    static let geteventUrl = "\(baseUrl)/getevents.php"
    static let updateeventUrl = "\(baseUrl)/updateevent.php"
    static let preferenceUrl = "\(baseUrl)/event_request.php"
   
    
    static let noteUrl = "\(baseUrl)/add_party_note.php"
    static let leftoverfoodideaURL = "\(baseUrl)/add_leftover_idea.php"
    static let manualentryUrl = "\(baseUrl)/add_menu_item.php"
    
    
    // Grocery List Endpoints
    static let addGroceryItemUrl = "\(baseUrl)/add_grocery_item.php"
    static let toggleGroceryItemUrl = "\(baseUrl)/toggle_grocery_item.php"
    static let listGroceryItemsUrl = "\(baseUrl)/list_grocery_items.php"
    static let deleteGroceryItemUrl = "\(baseUrl)/delete_grocery_item.php"
    
    // AI
    
    static let foofLeftOver = baseUrlAi+"recommend_food"
    static let foodai = baseUrl1Ai+"recommendations"
    static let budgetai = baseUrlAi+"recommendations"
}
