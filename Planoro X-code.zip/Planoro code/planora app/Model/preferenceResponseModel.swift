import Foundation

struct PreferenceResponseModel: Codable {
    let status: Bool
    let message: String
    let data: DataClass
}

struct DataClass: Codable {
    let id, guestCount: Int
    let eventType, cuisine, dietaryPreference, priceRange: String

    enum CodingKeys: String, CodingKey {
        case id
        case guestCount = "guest_count"
        case eventType = "event_type"
        case cuisine = "cuisine"
        case dietaryPreference = "dietary_preference"
        case priceRange = "price_range"
    }
}

struct MandatoryDish: Identifiable, Hashable {
    let id = UUID()
    let name: String
    let price: Int
}
