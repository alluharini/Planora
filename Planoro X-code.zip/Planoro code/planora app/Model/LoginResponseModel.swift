import Foundation

struct LoginResponseModel: Codable {
    let status: Bool
    let message: String
    let data:[ResponseData]
}

struct ResponseData: Codable {
    let id: Int
    let name: String
    let email: String
}


struct LeftOverFood: Codable {
    let data: [String]
    let message: String
    let status: Bool
}

