import Foundation

struct NoteResponseModel: Codable {
    let status: Bool
    let message: String
    let data: [NoteResponsesData]
    
    
    struct NoteResponsesData: Codable {
        let id: Int
        let note: String
    }
}

struct AIfood: Codable {
    let status: Bool
    let message: String
    let data: AIfooddata
}

struct AIfooddata: Codable {
    let totalGuests: Int
    let mandatoryDishes: [String]
    let recommendedDishes: [AIfooddRecommended]

    enum CodingKeys: String, CodingKey {
        case totalGuests = "total_guests"
        case mandatoryDishes = "mandatory_dishes"
        case recommendedDishes = "recommended_dishes"
    }
}

struct AIfooddRecommended: Codable, Hashable, Equatable  {
    let name: String
    let cuisine: String
    let diet: String
    let price: Int
}

