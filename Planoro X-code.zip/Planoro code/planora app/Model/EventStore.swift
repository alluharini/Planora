import Foundation

class EventStore: ObservableObject {
    @Published var events: [EventModel] = []

    func addEvent(from response: EventResponseModel.eventResponsesData) {
        let newEvent = EventModel(name: response.eventName, date: response.eventDate)
        events.insert(newEvent, at: 0)
    }
}
