import Foundation

struct EventResponseModel: Codable {
    let status: Bool
    let message: String
    let data: [eventResponsesData]
    
    
    struct eventResponsesData: Codable {
        let id: String
        let eventName, eventDate,email,status: String
        
        enum CodingKeys: String, CodingKey {
            case id
            case eventName = "event_name"
            case eventDate = "event_date"
            case email
            case status
            
        }
    }
}
struct GetEvent: Codable {
    let status: Bool
    let message: String
    let data: [GetEventDatum]
}
struct GetEventDatum: Codable,Identifiable {
    let id: Int
    let eventName, eventDate, email: String
    let status: Int

    enum CodingKeys: String, CodingKey {
        case id
        case eventName = "event_name"
        case eventDate = "event_date"
        case email, status
    }
}


struct UpdateEvent: Codable {
    let status: Bool
    let message: String
    let data: [UpdateEventDatum]
}

struct UpdateEventDatum: Codable {
    let id, status: Int
}
