import Foundation

struct ManualentryResponseModel: Codable {
    let status: Bool
    let message: String
    let data: [manualentryResponsesData]
    
    
    struct manualentryResponsesData: Codable {
        let id: Int
        let name: String
        let value: Float
    }
}

