import SwiftUI

struct BudgetEstimator: View {
    @State private var eventName: String = "" // Editable event name
    @State private var budget: String = ""
    let placeholderText = "Enter Event Name" // Placeholder for event input

    var body: some View {
        GeometryReader { geometry in
            VStack(spacing: geometry.size.height * 0.03) {
                // Title and Settings
                HStack {
                    Text("Budget Estimator")
                        .font(.system(size: geometry.size.width * 0.08, weight: .semibold, design: .serif))
                        .padding(.top,-50)
                        .foregroundColor(Color.purple)
                        .italic()
                    Spacer()
                                    }
                .padding(.horizontal, geometry.size.width * 0.06)
                .padding(.top, geometry.size.height * 0.03)

                // Editable Event Name
                TextField(placeholderText, text: $eventName)
                    .font(.system(size: geometry.size.width * 0.07, design: .serif))
                    .italic()
                    .padding()
                    .frame(width: geometry.size.width * 0.92, height: geometry.size.height * 0.08)
                    .background(Color(.systemGray4))
                    .cornerRadius(geometry.size.height * 0.04)

                // Budget Input
                TextField("Enter Your Budget", text: $budget)
                    .font(.system(size: geometry.size.width * 0.07, design: .serif))
                    .italic()
                    .padding()
                    .frame(width: geometry.size.width * 0.92, height: geometry.size.height * 0.08)
                    .background(Color(.systemGray4))
                    .cornerRadius(geometry.size.height * 0.04)
                    .keyboardType(.numberPad)

                // Graph Placeholder
                ZStack {
                    RoundedRectangle(cornerRadius: geometry.size.height * 0.04)
                        .fill(Color(.systemGray4))
                    Text("Graph")
                        .font(.system(size: geometry.size.width * 0.07, design: .serif))
                        .italic()
                        .foregroundColor(.black)
                }
                .frame(width: geometry.size.width * 0.97, height: geometry.size.height * 0.6) // Extend the graph area
            }
            .frame(width: geometry.size.width, height: geometry.size.height)
            .background(Color.white)
        }
        .edgesIgnoringSafeArea(.bottom)
    }
}

struct BudgetEstimatorView_Previews: PreviewProvider {
    static var previews: some View {
        BudgetEstimator()
    }
}
