import SwiftUI

struct DishSelectionView: View {
    @State private var mandatoryItems: [String] = [
        "Plain Rice", "Chapati", "Salad", "Papad", "Curd", "Pickle", "ice cream", "sweet", "pickle", "gulab jamun", "samosa", "cold drink", "juice", "chips", "pani puri"
    ]

    @State private var selectedItems: [AIfooddRecommended] = []
    @State private var guestAllocations: [AIfooddRecommended: Int] = [:]
    @State private var addMandatoryItems = false
    @State private var selectedMandatory: Set<String> = []

    let mandatoryPricesByLevel: [String: [String: Int]] = [
            "basic": [
                "Plain Rice": 8, "Chapati": 6, "Salad": 4, "Papad": 3, "Curd": 5,
                "Pickle": 2, "Ice Cream": 10, "Sweet": 8, "Gulab Jamun": 8,
                "Samosa": 7, "Cold Drink": 5, "Juice": 7, "Chips": 3, "Pani Puri": 7
            ],
            "medium": [
                "Plain Rice": 12, "Chapati": 10, "Salad": 6, "Papad": 5, "Curd": 8,
                "Pickle": 4, "Ice Cream": 15, "Sweet": 12, "Gulab Jamun": 12,
                "Samosa": 10, "Cold Drink": 8, "Juice": 10, "Chips": 5, "Pani Puri": 10
            ],
            "premium": [
                "Plain Rice": 20, "Chapati": 18, "Salad": 12, "Papad": 10, "Curd": 15,
                "Pickle": 8, "Ice Cream": 25, "Sweet": 22, "Gulab Jamun": 22,
                "Samosa": 18, "Cold Drink": 15, "Juice": 18, "Chips": 10, "Pani Puri": 18
            ]
        ]


    // Computed property to remove duplicate recommended dishes by name
    var uniqueRecommendedDishes: [AIfooddRecommended] {
        var seenNames = Set<String>()
        return Manager.shared.recommendedDish.filter { dish in
            if seenNames.contains(dish.name) {
                return false
            } else {
                seenNames.insert(dish.name)
                return true
            }
        }
    }

    var totalAssignedGuests: Int {
        guestAllocations.values.reduce(0, +)
    }

    var remainingGuests: Int {
        (Int(Manager.shared.totalGuest) ?? 0) - totalAssignedGuests
    }

    var isGuestAllocationValid: Bool {
        totalAssignedGuests == (Int(Manager.shared.totalGuest) ?? 0)
    }

    var totalPriceValue: Int {
        guestAllocations.reduce(0) { result, entry in
            let (dish, guestCount) = entry
            return result + (dish.price * guestCount)
        }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {

                // Recommended Menu Items
                Text("Recommended Menu")
                    .font(.title2)
                    .bold()
                    .foregroundColor(.purple)
                    .padding(.horizontal)

                ForEach(uniqueRecommendedDishes, id: \.name) { item in
                    VStack(alignment: .leading) {
                        HStack {
                            Text(item.name)
                                .italic()
                            Spacer()
                            Button(action: {
                                if selectedItems.contains(item) {
                                    selectedItems.removeAll { $0 == item }
                                    guestAllocations[item] = nil
                                } else {
                                    selectedItems.append(item)
                                    guestAllocations[item] = 0
                                }
                            }) {
                                ZStack {
                                    RoundedRectangle(cornerRadius: 4)
                                        .stroke(Color.black, lineWidth: 2)
                                        .frame(width: 24, height: 24)
                                    if selectedItems.contains(item) {
                                        Image(systemName: "checkmark")
                                            .font(.system(size: 18, weight: .bold))
                                            .foregroundColor(Color.purple)
                                    }
                                }
                            }
                        }

                        Text("Cuisine: \(item.cuisine)")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                        Text("Dietary: \(item.diet)")
                            .font(.subheadline)
                            .foregroundColor(.gray)

                        Text("Price: \(item.price)")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                    .padding(.horizontal)
                }

                // Guest Allocation
                if !selectedItems.isEmpty {
                    Text("Guest Allocation")
                        .font(.title2)
                        .bold()
                        .foregroundColor(.purple)
                        .padding(.horizontal)

                    Text("Remaining Guests to assign: \(remainingGuests)")
                        .italic()
                        .foregroundColor(remainingGuests == 0 ? .green : .red)
                        .padding(.horizontal)

                    ForEach(selectedItems, id: \.name) { item in
                        HStack {
                            Text(item.name)
                                .italic()
                            Spacer()
                            TextField(
                                "",
                                value: Binding(
                                    get: { guestAllocations[item] ?? 0 },
                                    set: { newValue in
                                        let oldValue = guestAllocations[item] ?? 0
                                        let difference = newValue - oldValue

                                        // Only update if we have enough remaining guests
                                        if difference <= remainingGuests + oldValue {
                                            guestAllocations[item] = newValue
                                        }
                                    }
                                ),
                                formatter: NumberFormatter()
                            )
                            .keyboardType(.numberPad)
                            .frame(width: 50)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                        }
                        .padding(.horizontal)
                    }
                }

                // Mandatory Items Toggle
                HStack {
                    Toggle(isOn: $addMandatoryItems) {
                        Text("Add Mandatory Menu Items for All Guests?")
                            .italic()
                            .foregroundColor(.purple)
                    }
                    .tint(.purple) // Sets the ON color of the toggle
                }
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 10)
                        .fill(Color.purple.opacity(0.3))  // Purple with 30% opacity
                )
                .cornerRadius(10)
                .padding(.horizontal)

                if addMandatoryItems {
                    ForEach(mandatoryItems, id: \.self) { item in
                        HStack {
                            Text("\(item.capitalized) - ₹\(mandatoryPricesByLevel[Manager.shared.selectedPriceLevel]?[item.capitalized] ?? 0)")
                                .italic()
                            Spacer()
                            Button(action: {
                                if selectedMandatory.contains(item) {
                                    selectedMandatory.remove(item)
                                } else {
                                    selectedMandatory.insert(item)
                                }
                            }) {
                                ZStack {
                                    RoundedRectangle(cornerRadius: 4)
                                        .stroke(Color.black, lineWidth: 2)
                                        .frame(width: 24, height: 24)

                                    if selectedMandatory.contains(item) {
                                        Image(systemName: "checkmark")
                                            .foregroundColor(.purple)
                                    }
                                }
                            }
                        }
                        .padding(.horizontal)
                    }
                }

                // View Budget Button
                NavigationLink(destination: BudgetView(
                    selectedDishes: selectedItems,
                    selectedMandatory: selectedMandatory,
                    guestAllocations: guestAllocations,
                    totalGuests: Manager.shared.totalGuest,
                    priceLevel: Manager.shared.selectedPriceLevel
                )) {
                    Text("View Budget →")
                        .font(.headline)
                        .italic()
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.purple)
                        .cornerRadius(25)
                        .padding(.horizontal)
                }
                .disabled(!isGuestAllocationValid)
                .padding(.bottom)
            }
        }
    }
}

struct DishSelectionView_Previews: PreviewProvider {
    static var previews: some View {
        DishSelectionView()
    }
}

