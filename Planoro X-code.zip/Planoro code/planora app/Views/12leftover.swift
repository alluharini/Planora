//integration done
//page done no changes

import SwiftUI

struct LeftoverIdeas: View {
    @State private var foodInput: String = ""
    @State private var navigate = false

    var body: some View {
        NavigationStack {
            GeometryReader { geometry in
                VStack(spacing: geometry.size.height * 0.04) {
                    Text("Leftover Ideas")
                        .font(.system(size: geometry.size.width * 0.09, weight: .regular, design: .serif))
                        .italic()
                        .foregroundColor(Color(red: 110/255, green: 89/255, blue: 207/255))
                        .padding(.top, geometry.size.height * 0.04)

                    Text("Enter the Food you want to Reuse")
                        .font(.system(size: geometry.size.width * 0.06, weight: .regular, design: .serif))
                        .italic()
                        .padding(.horizontal, geometry.size.width * 0.03)

                    TextField("Add Food", text: $foodInput)
                        .padding()
                        .frame(width: geometry.size.width * 0.95, height: geometry.size.height * 0.09)
                        .background(Color.purple.opacity(0.6))
                        .foregroundColor(.white)
                        .cornerRadius(geometry.size.height * 0.09 / 2)
                        .padding(.horizontal, geometry.size.width * 0.025)

                    Button(action: {
                        leftoverfoodideaApiCall(food_name: foodInput)
                        navigate = true
                        Manager.shared.foodInpu = foodInput
                    }) {
                        Text("Submit")
                            .font(.system(size: geometry.size.width * 0.07, weight: .regular, design: .serif))
                            .italic()
                            .foregroundColor(.white)
                            .frame(width: geometry.size.width * 0.6, height: geometry.size.height * 0.07)
                            .background(Color.black)
                            .cornerRadius(geometry.size.height * 0.07 / 2)
                    }
                    .padding(.top, geometry.size.height * 0.02)

                    Spacer()
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.white)
            }
            .navigationDestination(isPresented: $navigate) {
                ideaView()
            }
        }
    }

    func leftoverfoodideaApiCall(food_name: String) {
        let param = ["food_name": food_name]
        APIHandler.shared.postAPIValues(type:LeftoverfoodResponseModel.self,apiUrl: APIList.leftoverfoodideaURL,method:"POST",formData: param) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    print(response)
                case .failure(let err):
                    print(err)
                }
            }
        }
    }
}

struct LeftoverIdeas_Previews: PreviewProvider {
    static var previews: some View {
        LeftoverIdeas()
    }
}

