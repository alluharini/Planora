import SwiftUI

struct HomeView: View {
    @State private var hasSavedBudget: Bool = UserDefaults.standard.bool(forKey: "hasSavedBudget")
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("Event Dish Recommender")
                    .font(.system(size: 28, weight: .bold, design: .rounded))
                    .foregroundColor(.purple)
                    .shadow(color: .purple.opacity(0.2), radius: 2, x: 0, y: 2)
                    .padding(.top, 30)
                
                Spacer()
                
                if hasSavedBudget {
                    NavigationLink(destination: BudgetView(
                        selectedDishes: BudgetManager.shared.recommendedDish,
                        selectedMandatory: Set(BudgetManager.shared.selectedMandatory ?? []),
                        guestAllocations: BudgetManager.shared.guestAllocations ?? [:],
                        totalGuests: BudgetManager.shared.totalGuest,
                        priceLevel: BudgetManager.shared.selectedPriceLevel
                    )) {
                        HStack {
                            Image(systemName: "doc.text.fill")
                            Text("View Saved Budget")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.purple)
                        .foregroundColor(.white)
                        .cornerRadius(15)
                        .shadow(color: .purple.opacity(0.3), radius: 5, x: 0, y: 3)
                    }
                    .padding(.horizontal)
                }
                
                NavigationLink(destination: PreferenceView()) {
                    HStack {
                        Image(systemName: "plus.circle.fill")
                        Text(hasSavedBudget ? "Create New Budget" : "Start Planning")
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(15)
                    .shadow(color: .blue.opacity(0.3), radius: 5, x: 0, y: 3)
                }
                .padding(.horizontal)
                
                Spacer()
            }
            .padding()
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
} 
