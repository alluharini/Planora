//integration done
//page done no changes
import SwiftUI

// Response model for signup
struct SignupResponseModel: Codable {
    let status: Bool
    let message: String
    let data: [SignupData]
}

struct SignupData: Codable {
    let id: Int
    let name: String
    let email: String
}

struct signuppage: View {
    @State private var email = ""
    @State private var fullName = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    
    @State private var isEmailValid = true
    @State private var isPasswordValid = true
    @State private var isConfirmPasswordValid = true
    @State private var isProcessing = false
    @State private var navigateToLogin = false
    @State private var showAlert = false
    @State private var alertMessage = ""
    
    private func registerUser() {
        guard validateFields() else { return }
        
        isProcessing = true
        let parameters: [String: String] = [
            "email": email,
            "name": fullName,
            "password": password
        ]
        
        APIHandler.shared.postAPIValues(
            type: SignupResponseModel.self,
            apiUrl: APIList.registerUrl,
            method: "POST",
            formData: parameters
        ) { result in
            DispatchQueue.main.async {
                isProcessing = false
                switch result {
                case .success(let response):
                    if response.status {
                        alertMessage = response.message
                        showAlert = true
                        navigateToLogin = true
                    } else {
                        // If registration failed but we got a response, show the server's message
                        alertMessage = response.message
                        showAlert = true
                    }
                case .failure(let error):
                    // If it's a decoding error, the registration might have actually succeeded
                    if error is DecodingError {
                        // Try to proceed as if registration was successful
                        alertMessage = "Registration successful! Please log in."
                        showAlert = true
                        navigateToLogin = true
                    } else {
                        // For other errors, show the error message
                        alertMessage = "Registration failed: \(error.localizedDescription)"
                        showAlert = true
                    }
                }
            }
        }
    }

    private func validateFields() -> Bool {
        // Reset validation states
        isEmailValid = true
        isPasswordValid = true
        isConfirmPasswordValid = true
        
        // Check if fields are empty
        if email.isEmpty {
            isEmailValid = false
            alertMessage = "Email is required"
            showAlert = true
            return false
        }
        
        if fullName.isEmpty {
            alertMessage = "Full name is required"
            showAlert = true
            return false
        }
        
        if password.isEmpty {
            isPasswordValid = false
            alertMessage = "Password is required"
            showAlert = true
            return false
        }
        
        if confirmPassword.isEmpty {
            isConfirmPasswordValid = false
            alertMessage = "Please confirm your password"
            showAlert = true
            return false
        }
        
        // Validate email format
        if !isValidEmail(email) {
            isEmailValid = false
            alertMessage = "Please enter a valid email address"
            showAlert = true
            return false
        }
        
        // Check if passwords match
        if password != confirmPassword {
            isConfirmPasswordValid = false
            alertMessage = "Passwords do not match"
            showAlert = true
            return false
        }
        
        return true
    }

    private func isValidEmail(_ email: String) -> Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        let emailTest = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        return emailTest.evaluate(with: email)
    }

    var body: some View {
        NavigationStack {
            ZStack {
                // Background
                Image("background")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .edgesIgnoringSafeArea(.all)
                    .blur(radius: 4)
                
                // Semi-transparent overlay
                Color.black.opacity(0.3)
                    .edgesIgnoringSafeArea(.all)
                
                // Content
                GeometryReader { geometry in
                    VStack {
                        Spacer()
                        
                        VStack(spacing: 25) {
                            Text("Create Account")
                                .font(.system(size: min(geometry.size.width * 2.8, 45), weight: .bold))
                                .foregroundColor(.brown)
                                .shadow(radius: 2)

                            Text("Please fill out the information\n below")
                                .font(.system(size: min(geometry.size.width * 0.045, 18), weight: .bold))
                                .foregroundColor(.white)
                                .multilineTextAlignment(.center)
                                .padding(.bottom, 10)
                                .shadow(radius: 2)
                            
                            VStack(spacing: 20) {
                                VStack(spacing: 15) {
                                    TextField("Email", text: $email)
                                        .textFieldStyle(RoundedBorderTextFieldStyle())
                                        .keyboardType(.emailAddress)
                                        .autocapitalization(.none)
                                        .padding(.horizontal, 10)
                                        .padding(.vertical, 8)
                                        .background(Color.white.opacity(0.9))
                                        .foregroundColor(.black)
                                        .font(.system(size: min(geometry.size.width * 0.045, 18), weight: .medium))
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 10)
                                                .stroke(isEmailValid ? Color.white : Color.red, lineWidth: 3)
                                        )
                                    
                                    TextField("First and Last Name", text: $fullName)
                                        .textFieldStyle(RoundedBorderTextFieldStyle())
                                        .padding(.horizontal, 10)
                                        .padding(.vertical, 8)
                                        .background(Color.white.opacity(0.9))
                                        .foregroundColor(.black)
                                        .font(.system(size: min(geometry.size.width * 0.045, 18), weight: .medium))
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 10)
                                                .stroke(Color.white, lineWidth: 3)
                                        )
                                    
                                    SecureField("Password", text: $password)
                                        .textFieldStyle(RoundedBorderTextFieldStyle())
                                        .padding(.horizontal, 10)
                                        .padding(.vertical, 8)
                                        .background(Color.white.opacity(0.9))
                                        .foregroundColor(.black)
                                        .font(.system(size: min(geometry.size.width * 0.045, 18), weight: .medium))
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 10)
                                                .stroke(isPasswordValid ? Color.white : Color.red, lineWidth: 3)
                                        )
                                    
                                    SecureField("Confirm Password", text: $confirmPassword)
                                        .textFieldStyle(RoundedBorderTextFieldStyle())
                                        .padding(.horizontal, 10)
                                        .padding(.vertical, 8)
                                        .background(Color.white.opacity(0.9))
                                        .foregroundColor(.black)
                                        .font(.system(size: min(geometry.size.width * 0.045, 18), weight: .medium))
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 10)
                                                .stroke(isConfirmPasswordValid ? Color.white : Color.red, lineWidth: 3)
                                        )
                                }
                                .frame(width: min(geometry.size.width * 0.8, 600))
                                
                                Button(action: {
                                    if validateFields() {
                                        isProcessing = true
                                        registerUser()
                                    }
                                }) {
                                    Text(isProcessing ? "Creating..." : "Create Account")
                                        .font(.headline)
                                        .foregroundColor(.white)
                                        .frame(width: min(geometry.size.width * 0.8, 600), height: 50)
                                        .background(
                                            LinearGradient(gradient: Gradient(colors: [
                                                Color(red: 0.4, green: 0.2, blue: 0.8),
                                                Color(red: 0.3, green: 0.3, blue: 0.9)
                                            ]), startPoint: .leading, endPoint: .trailing)
                                        )
                                        .cornerRadius(10)
                                        .shadow(color: Color.black.opacity(0.3), radius: 5, x: 0, y: 2)
                                }
                                .disabled(isProcessing)
                            }
                            .frame(maxWidth: .infinity, alignment: .center)
                            
                            NavigationLink(destination: loginpage()) {
                                HStack {
                                    Text("Already a user?")
                                        .foregroundColor(.white)
                                        .font(.system(size: min(geometry.size.width * 0.05, 20), weight: .medium))
                                    Text("Please log in")
                                        .foregroundColor(.white)
                                        .font(.system(size: min(geometry.size.width * 0.05, 20), weight: .bold))
                                }
                                .padding(.top, 20)
                            }
                        }
                        .padding()
                        
                        Spacer()
                    }
                }
            }
            .navigationBarHidden(true)
            .alert(isPresented: $showAlert) {
                Alert(
                    title: Text("Registration"),
                    message: Text(alertMessage),
                    dismissButton: .default(Text("OK")) {
                        if navigateToLogin {
                            navigateToLogin = false
                        }
                    }
                )
            }
        }
    }
}

struct signuppage_Previews: PreviewProvider {
    static var previews: some View {
        signuppage()
    }
}





