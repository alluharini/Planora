import Foundation

class BudgetManager {
    static let shared = BudgetManager()
    
    var totalGuest: String = ""
    var selectedCuisines: String = ""
    var selectedDietary: String = ""
    var selectedPriceLevel: String = ""
    var selectedEventType: String = ""
    var recommendedDish: [AIfooddRecommended] = []
    var selectedMandatory: [String]?
    var guestAllocations: [AIfooddRecommended: Int]?
    
    private init() {}
    
    func saveBudgetData(selectedDishes: [AIfooddRecommended], selectedMandatory: Set<String>, guestAllocations: [AIfooddRecommended: Int]) {
        self.recommendedDish = selectedDishes
        self.selectedMandatory = Array(selectedMandatory)
        self.guestAllocations = guestAllocations
    }
    
    func clearBudgetData() {
        self.recommendedDish = []
        self.selectedMandatory = nil
        self.guestAllocations = nil
        UserDefaults.standard.set(false, forKey: "hasSavedBudget")
    }
} 
