import SwiftUI

struct HowToUseView: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text("Welcome to Planora")
                    .font(.title)
                    .bold()
                
                Text("Thank you very much for downloading the App!")
                    .font(.headline)
                
                VStack(alignment: .leading, spacing: 15) {
                    Text("Here is a quick walkthrough regarding the most important features in this App:")
                        .font(.subheadline)
                    
                    FeatureRow(number: "1", text: "The homepage shows all the events you're part of.")
                    FeatureRow(number: "2", text: "Tap \"Create Event\" to quickly set up a new event.")
                    FeatureRow(number: "3", text: "Just enter the details - and your event is ready in seconds!")
                    FeatureRow(number: "4", text: "Easily add drinks and food to your event from the event info page.")
                    FeatureRow(number: "5", text: "You can find a Budget Estimator on each event's info page to help manage expenses.")
                    FeatureRow(number: "6", text: "In the \"More\" section, explore smart tools like Leftover Ideas, Notes list, and Party Notes - dive in to make the most of your event!")
                    FeatureRow(number: "7", text: "In Settings, you can manage your account and share your feedback with us.")
                }
            }
            .padding()
        }
    }
}
struct FeedbackView: View {
    var body: some View {
        VStack(spacing: 20) {
            Text("Thanks for downloading!")
                .font(.largeTitle)
                .bold()
                .foregroundColor(Color.purple)
                .multilineTextAlignment(.center)
            
            Text("We hope you enjoy using Planora to make your party planning easier and more fun.")
                .font(.body)
                .multilineTextAlignment(.center)
                .padding(.horizontal)
            
            Text("Your feedback means a lot to us and helps improve the app.")
                .font(.body)
                .multilineTextAlignment(.center)
                .padding(.horizontal)
            
            Text("Please visit the App Store to leave a review or share your thoughts.")
                .font(.body)
                .multilineTextAlignment(.center)
                .padding(.horizontal)
            
            Text("Thank you for being part of the Planora community!")
                .font(.body)
                .italic()
                .multilineTextAlignment(.center)
                .padding(.horizontal)
        }
        .padding()
        .frame(maxWidth: .infinity, maxHeight: .infinity)  // Fill available space
        .background(Color.white)
        .edgesIgnoringSafeArea(.all)
        .multilineTextAlignment(.center)
        .background(
            LinearGradient(
                gradient: Gradient(colors: [Color.purple.opacity(0.2), Color.purple.opacity(0.05)]),
                startPoint: .top,
                endPoint: .bottom
            )
        )
    }
}

struct ContactUsView: View {
    var body: some View {
        List {
            Section(header: Text("Customer Support")) {
                ContactRow(icon: "envelope.fill", title: "Email", detail: "planoraoffical@gmail.com")
                ContactRow(icon: "phone.fill", title: "Phone", detail: "+91 8977527252")
                ContactRow(icon: "clock.fill", title: "Hours", detail: "Mon-Fri: 9AM - 6PM IST")
            }
            
            Section(header: Text("Social Media")) {
                ContactRow(icon: "camera.fill", title: "Instagram", detail: "@Planoraoffical")
            }
        }
    }
}

struct LanguageSettingsView: View {
    @State private var selectedLanguage = "English"
    let languages = ["English"]
    
    var body: some View {
        Form {
            Section(header: Text("Select Language")) {
                Picker("Language", selection: $selectedLanguage) {
                    ForEach(languages, id: \.self) { language in
                        Text(language)
                    }
                }
            }
            
            Section(header: Text("About Language Settings")) {
                Text("Changing the language will update the app's interface language. Some content may remain in the original language.")
                    .font(.footnote)
                    .foregroundColor(.gray)
            }
        }
    }
}
struct TermsOfServiceView: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text("Terms of Service")
                    .font(.title)
                    .bold()
                
                Group {
                    Text("Last Updated: March 2024")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                    
                    Text("1. Acceptance of Terms")
                        .font(.headline)
                    Text("By accessing and using Planora, you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use the application.")
                    
                    Text("2. User Responsibilities")
                        .font(.headline)
                    Text("You are responsible for maintaining the confidentiality of your account and for all activities that occur under your account. You must immediately notify us of any unauthorized use of your account or any other breach of security.")
                    
                    Text("3. Content Guidelines")
                        .font(.headline)
                    Text("Users must not post content that is illegal, harmful, threatening, abusive, or otherwise objectionable. This includes but is not limited to content that promotes hate speech, discrimination, or harassment.")
                    
                    Text("4. Event Management")
                        .font(.headline)
                    Text("When creating events, you must provide accurate information and ensure compliance with local laws and regulations. You are responsible for the content and conduct of your events.")
                    
                    Text("5. Payment and Refunds")
                        .font(.headline)
                    Text("All payments are processed securely through our payment partners. Refund policies vary by event type and are clearly stated during the booking process.")
                    
                    Text("6. Intellectual Property")
                        .font(.headline)
                    Text("All content, features, and functionality of Planora are owned by us and are protected by international copyright, trademark, and other intellectual property laws.")
                    
                    Text("7. Termination")
                        .font(.headline)
                    Text("We reserve the right to terminate or suspend your account at any time for violations of these terms or for any other reason at our sole discretion.")
                    
                    Text("8. Limitation of Liability")
                        .font(.headline)
                    Text("Planora shall not be liable for any indirect, incidental, special, consequential, or punitive damages resulting from your use of or inability to use the service.")
                }
            }
            .padding()
        }
    }
}

struct PrivacyPolicyView: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text("Privacy Policy")
                    .font(.title)
                    .bold()
                
                Group {
                    Text("Last Updated: March 2024")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                    
                    Text("1. Information We Collect")
                        .font(.headline)
                    Text("We collect information that you provide directly to us, including your name, email address, phone number, event details, and payment information. We also collect information about your device, location, and usage patterns.")
                    
                    Text("2. How We Use Your Information")
                        .font(.headline)
                    Text("We use your information to provide, maintain, and improve our services, to communicate with you about your account and events, to process payments, to send you updates and marketing communications (with your consent), and to protect our users.")
                    
                    Text("3. Information Sharing")
                        .font(.headline)
                    Text("We do not sell your personal information. We may share your information with service providers who assist us in operating our platform, with event organizers when necessary, and with law enforcement when required by law.")
                    
                    Text("4. Data Security")
                        .font(.headline)
                    Text("We implement appropriate technical and organizational measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction.")
                    
                    Text("5. Your Rights")
                        .font(.headline)
                    Text("You have the right to access, correct, or delete your personal information. You can also object to the processing of your data, request data portability, and withdraw your consent at any time.")
                    
                    Text("6. Cookies and Tracking")
                        .font(.headline)
                    Text("We use cookies and similar tracking technologies to improve your experience, analyze usage patterns, and personalize content. You can control cookie settings through your browser preferences.")
                    
                    Text("7. Children's Privacy")
                        .font(.headline)
                    Text("Our services are not intended for children under 13. We do not knowingly collect personal information from children under 13.")
                    
                    Text("8. International Data Transfers")
                        .font(.headline)
                    Text("Your information may be transferred to and processed in countries other than your country of residence. We ensure appropriate safeguards are in place for such transfers.")
                    
                    Text("9. Changes to Privacy Policy")
                        .font(.headline)
                    Text("We may update this privacy policy from time to time. We will notify you of any changes by posting the new policy on this page and updating the 'Last Updated' date.")
                }
            }
            .padding()
        }
    }
}

// Helper Views
struct FeatureRow: View {
    let number: String
    let text: String
    
    var body: some View {
        HStack(alignment: .top) {
            Text(number)
                .font(.headline)
                .foregroundColor(.blue)
                .frame(width: 25)
            Text(text)
                .font(.body)
        }
    }
}

struct ContactRow: View {
    let icon: String
    let title: String
    let detail: String
    
    var body: some View {
        HStack {
            Image(systemName: icon)
                .foregroundColor(.blue)
                .frame(width: 25)
            VStack(alignment: .leading) {
                Text(title)
                    .font(.headline)
                Text(detail)
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
        }
    }
}

struct DataUsageView: View {
    var body: some View {
        List {
            Section(header: Text("Data Collection")) {
                Text("We collect data to improve your experience and provide better services.")
            }
            
            Section(header: Text("Types of Data")) {
                Text("• Account Information")
                Text("• Event Details")
                Text("• Usage Statistics")
                Text("• Device Information")
            }
            
            Section(header: Text("Data Protection")) {
                Text("Your data is encrypted and stored securely. We never sell your personal information to third parties.")
            }
        }
    }
}

#Preview {
    NavigationView {
        HowToUseView()
    }
}

