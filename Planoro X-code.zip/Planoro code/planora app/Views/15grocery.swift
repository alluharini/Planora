//integration done
//only listing done checked in database
//but it doesent checked and delete
//check that and close this
import SwiftUI

struct GroceryItem: Identifiable {
    let id = UUID()
    var name: String
    var isChecked: Bool = false
}

struct GroceryListView: View {
    @State private var items: [GroceryItem] = []
    @State private var newItemName = ""
    
    var body: some View {
        GeometryReader { geometry in
            VStack(alignment: .leading) {
                HStack {
                    Spacer()
                    Text("Grocery List")
                        .font(.system(size: min(geometry.size.width * 0.06, 32), weight: .bold, design: .serif))
                        .italic()
                        .foregroundColor(Color.purple)
                        .padding(.trailing, geometry.size.width * 0.07)
                }
                .padding(.top, geometry.size.height * 0.02)
                .padding(.horizontal)
                
                // TextField to add a new grocery item
                HStack {
                    TextField("Enter grocery item", text: $newItemName)
                        .padding()
                        .background(Color(.systemGray6))
                        .cornerRadius(8)
                        .font(.system(size: min(geometry.size.width * 0.045, 20)))
                    
                    Button(action: {
                        if !newItemName.isEmpty {
                            let newItem = GroceryItem(name: newItemName)
                            items.insert(newItem, at: 0)
                            groceryApiCall(name: newItemName) 
                            newItemName = ""
                        }
                    }) {
                        Text("Add")
                            .font(.system(size: min(geometry.size.width * 0.045, 20), weight: .medium))
                            .foregroundColor(.white)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 12)
                            .background(Color.purple)
                            .cornerRadius(8)
                    }
                }
                .padding(.horizontal)
                
                ScrollView {
                    VStack(spacing: geometry.size.height * 0.015) {
                        ForEach(items.indices, id: \.self) { index in
                            HStack {
                                Button(action: {
                                    items[index].isChecked.toggle()
                                }) {
                                    RoundedRectangle(cornerRadius: 6)
                                        .stroke(Color.black, lineWidth: 2)
                                        .frame(width: min(geometry.size.width * 0.08, 32), height: min(geometry.size.width * 0.08, 32))
                                        .overlay(
                                            items[index].isChecked ?
                                                Image(systemName: "checkmark")
                                                    .font(.system(size: min(geometry.size.width * 0.04, 18), weight: .bold))
                                                    .foregroundColor(.black)
                                                : nil
                                        )
                                }
                                .buttonStyle(PlainButtonStyle())
                                
                                Text(items[index].name)
                                    .font(.system(size: min(geometry.size.width * 0.045, 20), weight: .medium, design: .serif))
                                    .italic()
                                    .foregroundColor(.black)
                                    .padding(.leading, geometry.size.width * 0.02)
                                
                                Spacer()
                                
                                Button(action: {
                                    items.remove(at: index)
                                }) {
                                    Image(systemName: "trash")
                                        .font(.system(size: min(geometry.size.width * 0.045, 20)))
                                        .foregroundColor(.red)
                                        .padding(8)
                                }
                                .buttonStyle(PlainButtonStyle())
                            }
                            .padding(.vertical, 8)
                            .padding(.horizontal, 12)
                            .background(Color.white)
                            .cornerRadius(10)
                            .shadow(color: Color.black.opacity(0.1), radius: 2, x: 0, y: 1)
                        }
                    }
                }
                .padding()
                .background(Color(.systemGray5))
                .cornerRadius(16)
                .padding()
                
                Spacer()
            }
            .background(Color(.systemGray6).ignoresSafeArea())
        }
    }
    func groceryApiCall(name:String) {
        
        let param = ["name":name]
        
        APIHandler.shared.postAPIValues(type: AddnotesResponseModel.self, apiUrl: APIList.addGroceryItemUrl, method: "POST", formData: param) { result in
            DispatchQueue.main.sync {
                switch result {
                case .success(let response):
                    print(response)
                case .failure(let err):
                    print(err)
                }
            }
            
        }
    }

}

struct GroceryListView_Previews: PreviewProvider {
    static var previews: some View {
        GroceryListView()
    }
}

