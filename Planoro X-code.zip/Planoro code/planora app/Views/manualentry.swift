//integration done
//updating in database
//checked the integration no issues

import SwiftUI

struct ManualEntryView: View {
    @State private var menuName: String = ""
    @State private var dishValue: String = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 30) {
            Text("Manual Entry")
                .font(.system(size: 34, weight: .bold, design: .serif))
                .italic()
                .foregroundColor(.purple)

            Text("Add new food and drinks by entering the name below")
                .font(.system(size: 18, weight: .medium, design: .serif))
                .italic()

            Group {
                TextField("Name of the menu", text: $menuName)
                    .padding()
                    .frame(height: 60)
                    .background(Color(white: 0.97))
                    .overlay(RoundedRectangle(cornerRadius: 40).stroke(Color.black, lineWidth: 3))
                    .font(.system(size: 20, weight: .medium, design: .serif))
                    .italic()

                TextField("Approx Value of the Dish", text: $dishValue)
                    .padding()
                    .frame(height: 60)
                    .background(Color(white: 0.97))
                    .overlay(RoundedRectangle(cornerRadius: 40).stroke(Color.black, lineWidth: 3))
                    .font(.system(size: 20, weight: .medium, design: .serif))
                    .italic()
            }

            Button(action: {
                manualentryApiCall(name: menuName, value: dishValue)
            }) {
                Text("Save")
                    .font(.system(size: 24, weight: .semibold, design: .serif))
                    .italic()
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 60)
                    .background(Color.black)
                    .cornerRadius(40)
            }

            Spacer()
        }
        .padding()
    }
    func manualentryApiCall(name: String,value: String) {
        let param = ["name": name,"value": value]
        APIHandler.shared.postAPIValues(type:ManualentryResponseModel.self,apiUrl: APIList.manualentryUrl,method:"POST",formData: param) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    print(response)
                case .failure(let err):
                    print(err)
                }
            }
        }
    }
}

struct ManualEntryView_Previews: PreviewProvider {
    static var previews: some View {
        ManualEntryView()
    }
}
