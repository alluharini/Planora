import SwiftUI

@main
struct PlanoraApp: App {
    @StateObject var eventStore = EventStore()

    var body: some Scene {
        WindowGroup {
            welcomepage()
                .environmentObject(eventStore)
        }
    }
}

struct getstartedView: View {
    var body: some View {
        getstarted()
    }
}

struct loginview: View {
    var body: some View {
        loginpage()
    }
}

struct signUpview: View {
    var body: some View {
        signuppage()
    }
}
struct homepageView: View {
    var body: some View {
        homepage()
    }
}
struct CreateEventView: View {
    var body: some View {
        CreateEventPage()
    }
}

struct BudgetEstimatorView: View {
    var body: some View {
        BudgetEstimator()
    }
}
struct MoreView: View {
    var body: some View {
        MorePageView()
    }
}

struct leftoverIdeasView: View {
    var body: some View {
        LeftoverIdeasView()
    }
}

struct PartyNotesView: View {
    var body: some View {
        PartyNotes()
    }
}

struct ideaView: View {
    var body: some View {
        LeftoverIdeasView()
    }
}


struct groceryListView: View {
    var body: some View {
        GroceryListView()
    }
}




