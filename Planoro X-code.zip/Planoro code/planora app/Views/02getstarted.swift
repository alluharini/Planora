import SwiftUI

struct getstarted: View {
    var body: some View {
        NavigationView {
            ZStack {
                // Fullscreen Background Image with Gradient
                Image("party")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea() // Ensures full screen coverage
                    .overlay(
                        LinearGradient(
                            gradient: Gradient(colors: [
                                Color.purple.opacity(0.7),
                                Color.purple.opacity(0.5),
                                Color.purple.opacity(0.3)
                            ]),
                            startPoint: .top,
                            endPoint: .bottom
                        )
                    )

                GeometryReader { geometry in
                    VStack(spacing: geometry.size.height * 0.03) {
                        NavigationLink(destination: loginpage()) {
                            HStack {
                                Image(systemName: "person.fill")
                                    .font(.system(size: geometry.size.width * 0.05))
                                Text("Login")
                                    .font(.system(size: geometry.size.width * 0.05, weight: .semibold))
                            }
                            .foregroundColor(.white)
                            .frame(width: geometry.size.width * 0.7, height: geometry.size.height * 0.07)
                            .background(
                                RoundedRectangle(cornerRadius: 15)
                                    .fill(.ultraThinMaterial)
                            )
                            .overlay(
                                RoundedRectangle(cornerRadius: 15)
                                    .stroke(Color.white.opacity(0.5), lineWidth: 1)
                            )
                            .shadow(color: .black.opacity(0.2), radius: 10, x: 0, y: 5)
                        }

                        NavigationLink(destination: signuppage()) {
                            HStack {
                                Image(systemName: "person.badge.plus.fill")
                                    .font(.system(size: geometry.size.width * 0.05))
                                Text("Sign Up")
                                    .font(.system(size: geometry.size.width * 0.05, weight: .semibold))
                            }
                            .foregroundColor(.white)
                            .frame(width: geometry.size.width * 0.7, height: geometry.size.height * 0.07)
                            .background(
                                RoundedRectangle(cornerRadius: 15)
                                    .fill(.ultraThinMaterial)
                            )
                            .overlay(
                                RoundedRectangle(cornerRadius: 15)
                                    .stroke(Color.white.opacity(0.5), lineWidth: 1)
                            )
                            .shadow(color: .black.opacity(0.2), radius: 10, x: 0, y: 5)
                        }
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
                }
            }
            .navigationBarHidden(true)
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

struct GetStarted_Previews: PreviewProvider {
    static var previews: some View {
        getstarted()
            .previewDevice("iPhone 16 Pro")
    }
}

