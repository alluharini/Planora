import SwiftUI

struct FoodRecommendation: Identifiable {
    let id = UUID()
    let name: String
    let dietary: String
    let cuisine: String
    let price: String
    let imageName: String
}

struct AIRecommendationsView: View {
    let recommendations: [FoodRecommendation] = [
        FoodRecommendation(name: "Pizza", dietary: "Vegetarian", cuisine: "Italian", price: "$$", imageName: "pizza"),
        FoodRecommendation(name: "Sushi", dietary: "Pescatarian", cuisine: "Japanese", price: "$$$", imageName: "sushi"),
        FoodRecommendation(name: "Salad", dietary: "Vegan", cuisine: "Mediterranean", price: "$", imageName: "salad"),
        FoodRecommendation(name: "Burger", dietary: "Non-Veg", cuisine: "American", price: "$$", imageName: "burger"),
        FoodRecommendation(name: "Tacos", dietary: "Vegetarian", cuisine: "Mexican", price: "$", imageName: "tacos"),
        FoodRecommendation(name: "Curry", dietary: "Vegan", cuisine: "Indian", price: "$$", imageName: "curry")
    ]

    var body: some View {
        GeometryReader { geometry in
            let width = geometry.size.width
            let spacing = width * 0.04
            let itemSize = width * 0.42
            let columns = [
                GridItem(.flexible(), spacing: spacing),
                GridItem(.flexible(), spacing: spacing)
            ]

            ScrollView {
                VStack(spacing: spacing) {
                    Text("AI Recommendations")
                        .font(.system(size: width * 0.08, weight: .bold, design: .serif))
                        .italic()
                        .foregroundColor(.purple)
                        .padding(.top, -10)

                    LazyVGrid(columns: columns, spacing: spacing) {
                        ForEach(recommendations) { rec in
                            VStack(spacing: spacing * 0.3) {
                                ZStack(alignment: .bottomTrailing) {
                                    Image(rec.imageName)
                                        .resizable()
                                        .scaledToFill()
                                        .frame(width: itemSize, height: itemSize)
                                        .clipped()
                                        .cornerRadius(itemSize * 0.2)

                                    Button(action: {
                                        print("Added \(rec.name)")
                                    }) {
                                        Image(systemName: "plus.circle.fill")
                                            .resizable()
                                            .frame(width: itemSize * 0.15, height: itemSize * 0.15)
                                            .foregroundColor(.white)
                                            .background(Color.black.opacity(0.6))
                                            .clipShape(Circle())
                                            .shadow(radius: 2)
                                            .padding(itemSize * 0.06)
                                    }
                                }

                                Group {
                                    Text(rec.name)
                                        .font(.system(size: itemSize * 0.12, weight: .semibold, design: .serif))
                                    Text(rec.dietary)
                                    Text(rec.cuisine)
                                    Text(rec.price)
                                }
                                .italic()
                                .font(.system(size: itemSize * 0.10, design: .serif))
                            }
                        }
                    }
                    .padding(.horizontal, spacing)

                    Spacer(minLength: spacing)
                }
            }
            .background(Color.white.ignoresSafeArea())
        }
    }
}

struct AIRecommendationsView_Previews: PreviewProvider {
    static var previews: some View {
        AIRecommendationsView()
    }
}

