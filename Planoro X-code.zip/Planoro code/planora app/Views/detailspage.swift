import SwiftUI

struct EventView: View {
    @State private var showEventDetails = false
    @Environment(\.presentationMode) var presentationMode
    @State private var eventDeleted = false
    
    var body: some View {
        NavigationView {
            GeometryReader { geometry in
                let width = geometry.size.width
                let height = geometry.size.height
                let padding: CGFloat = 16
                let buttonHeight = height * 0.09
                let smallButtonHeight = height * 0.05
                let foodSectionHeight = (height - (buttonHeight + smallButtonHeight + padding * 3)) / 2
                


                VStack(spacing: padding) {
                    
                    HStack {
                        Spacer()
                        Text("Event")
                            .font(.system(size: 28, weight: .bold, design: .serif))
                            .italic()
                            .foregroundColor(.black)
                            .padding(.top,-30)
                        Spacer()
                    }
                    .padding(.horizontal, padding)
                    .navigationBarItems(trailing: Button(action: {
                        eventDeleted = true
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                            presentationMode.wrappedValue.dismiss()
                        }
                    }) {
                        Image(systemName: "trash")
                            .font(.system(size: 28))
                            .foregroundColor(.red)
                    })

                    // Full Details Toggle
                    Button(action: {
                        showEventDetails.toggle()
                    }) {
                        HStack {
                            Text("Full Details")
                                .font(.system(size: 24, weight: .medium, design: .serif))
                                .italic()
                                .foregroundColor(.white)
                            Spacer()
                            Image(systemName: showEventDetails ? "chevron.up" : "chevron.down")
                                .font(.system(size: 24))
                                .foregroundColor(.white)
                        }
                        .padding()
                        .frame(height: buttonHeight)
                        .background(Color.purple.opacity(0.6))
                        .cornerRadius(40)
                        .padding(.horizontal, padding)
                    }

                    // Event details
                    if showEventDetails {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Event Name: Birthday Bash")
                            Text("Date: May 15, 2025")
                        }
                        .font(.system(size: 18, weight: .regular))
                        .padding(.horizontal, padding)
                    }

                    // AI Recommendations & Manual Entry Navigation
                    HStack(spacing: padding) {
                        NavigationLink(destination: AIRecommendationsView()) {
                            Text("AI Recommendations")
                                .font(.system(size: 18, weight: .medium, design: .serif))
                                .italic()
                                .foregroundColor(.white)
                                .frame(width: (width - padding * 3) / 2, height: smallButtonHeight)
                                .background(Color.purple.opacity(0.6))
                                .cornerRadius(smallButtonHeight / 2)
                        }

                        NavigationLink(destination: ManualEntryView()) {
                            Text("Manual Entry")
                                .font(.system(size: 18, weight: .medium, design: .serif))
                                .italic()
                                .foregroundColor(.white)
                                .frame(width: (width - padding * 3) / 2, height: smallButtonHeight)
                                .background(Color.purple.opacity(0.6))
                                .cornerRadius(smallButtonHeight / 2)
                        }
                    }
                    .padding(.horizontal, padding)

                    // AI & Manual Food Sections
                    VStack(spacing: padding) {
                        VStack {
                            Text("AI Food")
                                .font(.system(size: 24, weight: .medium, design: .serif))
                                .italic()
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity, alignment: .center)
                                .padding(.horizontal)
                                .padding(.top, 10)

                            ScrollView {
                                VStack(spacing: 12) {
                                    Text("No AI recommendations yet")
                                        .foregroundColor(.white.opacity(0.8))
                                        .padding()
                                }
                            }
                        }
                        .frame(height: foodSectionHeight)
                        .frame(maxWidth: .infinity)
                        .background(Color.purple.opacity(0.6))
                        .cornerRadius(40)

                        VStack(alignment: .leading) {
                            Text("Manual Food")
                                .font(.system(size: 24, weight: .medium, design: .serif))
                                .italic()
                                .foregroundColor(.white)
                                .padding(.horizontal, 25)
                                .padding(.top, 10)

                            ScrollView {
                                VStack(spacing: 12) {
                                    Text("No manual entries yet")
                                        .foregroundColor(.white.opacity(0.8))
                                        .padding()
                                }
                            }
                        }
                        .frame(height: foodSectionHeight)
                        .frame(maxWidth: .infinity)
                        .background(Color.purple.opacity(0.6))
                        .cornerRadius(40)
                    }
                    .padding(.horizontal, padding)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.white)
            }
            .background(Color.white.ignoresSafeArea())
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

struct EventView_Previews: PreviewProvider {
    static var previews: some View {
        EventView()
    }
}





