import SwiftUI

struct welcomepage: View {
    @State private var showGetStarted = false

    var body: some View {
        GeometryReader { geometry in
            VStack(spacing: geometry.size.height * 0.02) {
                VStack(spacing: 0) {
                    Text("Welcome to")
                        .font(.system(size: geometry.size.width * 0.15))
                        .fontWeight(.bold)
                        .foregroundColor(.purple)
                        .padding(.top, 10)

                    Text("Planora")
                        .font(.system(size: geometry.size.width * 0.15))
                        .fontWeight(.bold)
                        .foregroundColor(.purple)
                        .padding(.top, -5)
                }
                .multilineTextAlignment(.center)
                .padding(.horizontal)

                Text("Where Every Detail Meets Perfection")
                    .font(.system(size: geometry.size.width * 0.05))
                    .fontWeight(.semibold)
                    .foregroundColor(Color.purple.opacity(0.7))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 14)
                    .padding(.top, -5)

                Image("party")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: geometry.size.height * 0.5)
                    .cornerRadius(30)
                    .padding(.top, geometry.size.height * 0.03)

                Button(action: {
                    showGetStarted = true
                }) {
                    Text("Get Started")
                        .font(.system(size: geometry.size.width * 0.08))
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.black)
                        .cornerRadius(12)
                }
                .padding(.top, geometry.size.height * 0.03)
                .padding(.horizontal, geometry.size.width * 0.15)
                .fullScreenCover(isPresented: $showGetStarted) {
                    getstarted()
                }

                Spacer(minLength: 20)
            }
            .frame(width: geometry.size.width, height: geometry.size.height)
        }
    }
}


struct welcomepage_Previews: PreviewProvider {
    static var previews: some View {
        welcomepage()
            .previewDevice("iPhone 16 Pro")
    }
}
