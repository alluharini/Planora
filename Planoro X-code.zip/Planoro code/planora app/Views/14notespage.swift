//integration done
//page done no changes
import SwiftUI

struct PartyNotes: View {
    @State private var noteText: String = ""
    
    var body: some View {
        GeometryReader { geometry in
            VStack(alignment: .trailing) {
                // Title
                Text("Party Notes")
                    .font(.system(size: 36, weight: .regular, design: .serif))
                    .italic()
                    .foregroundColor(Color.purple)
                    .padding(.top, 40)
                    .padding(.trailing, 24)
                
                Spacer().frame(height: 1)
                
                // Main note area
                ZStack(alignment: .top) {
                    // Background with rounded corners
                    RoundedRectangle(cornerRadius: 40)
                        .fill(Color(white: 0.93))
                        .shadow(color: .gray.opacity(0.2), radius: 8, x: 0, y: 4)
                    
                    VStack(spacing: 0) {
                        // Decorative header
                        Text("The night’s over, but your story isn’t\n--- write it here ---")
                            .font(.custom("UnifrakturCook-Bold", size: 22))
                            .multilineTextAlignment(.center)
                            .padding(.top, 2)
                            .padding(.bottom, 12)
                        
                        // Writable area without scroll
                        TextEditor(text: $noteText)
                            .padding(.horizontal, 1)
                            .padding(.bottom, 1)
                            .background(RoundedRectangle(cornerRadius: 20).stroke(Color.black, lineWidth: 5)) // Add a border for visibility
                            .font(.system(size: 10, design: .serif))
                            .opacity(0.95)
                            .padding(.top, 8) // Move up a bit
                            .foregroundColor(noteText.isEmpty ? .gray : .black) // Change text color for placeholder
                            .overlay(
                                Text("Write your lines here...")
                                    .foregroundColor(.gray)
                                    .opacity(noteText.isEmpty ? 1 : 0) // Show placeholder when there's no text
                                    .padding(.horizontal, 19)
                                    .padding(.top, 20),
                                alignment: .topLeading
                            )
                        Button("Save Note") {
                            partynotesApiCall(note: noteText)
                        }
                        .padding()
                        .background(Color.purple)
                        .foregroundColor(.white)
                        .cornerRadius(10)

                    }
                }
                .frame(
                    width: geometry.size.width * 0.96,
                    height: geometry.size.height * 0.905,
                    alignment: .center
                )
                .padding(.top, 8)
                
                Spacer()
            }
            .frame(width: geometry.size.width, height: geometry.size.height)
            .background(Color.white.ignoresSafeArea())
        }
    }
    func partynotesApiCall(note:String) {
      let param = ["note":note]
        APIHandler.shared.postAPIValues(type: NoteResponseModel.self, apiUrl: APIList.noteUrl, method: "POST", formData: param) { result in
           DispatchQueue.main.sync {
               switch result {
               case .success(let response):
                  print(response)
               case .failure(let err):
                  print(err)
                }
            }
            
        }
   }
}

// Preview
struct PartyNotesView_Previews: PreviewProvider {
    static var previews: some View {
        PartyNotes()
    }
}

