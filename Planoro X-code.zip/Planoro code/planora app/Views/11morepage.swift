import SwiftUI

struct MorePageView: View {
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    
    var body: some View {
        NavigationView {
            GeometryReader { geometry in
                ZStack {
                    Color.white
                        .ignoresSafeArea()
                    
                    VStack(spacing: 0) {
                        // Header
                        HStack(alignment: .center) {
                            Text("More page")
                                .font(.system(size: min(geometry.size.width * 0.09, 40), weight: .regular, design: .serif))
                                .foregroundColor(Color.purple)
                                .padding(.leading,10)
                            
                            Spacer()
                            
                            NavigationLink(destination: SettingsView()) {
                                VStack(spacing: 4) {
                                    Image(systemName: "gearshape.fill")
                                        .resizable()
                                        .frame(width: min(geometry.size.width * 0.08, 45), height: min(geometry.size.width * 0.08, 45))
                                        .foregroundColor(.black)
                                    
                                    Text("Settings")
                                        .font(.system(size: min(geometry.size.width * 0.05, 28), weight: .regular, design: .serif))
                                        .foregroundColor(.black)
                                }
                                .padding(.trailing)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                        .padding(.top, horizontalSizeClass == .regular ? geometry.safeAreaInsets.top : 10)
                        .padding(.bottom, 10)
                        .background(Color.white)
                        
                        // Scrollable clickable tiles
                        ScrollView {
                            VStack(spacing: geometry.size.height * 0.04) {
                                ForEach(contentData) { item in
                                    NavigationLink(destination: item.destination) {
                                        VStack {
                                            Image(item.imageName)
                                                .resizable()
                                                .aspectRatio(contentMode: .fill)
                                                .frame(height: geometry.size.height * 0.4)
                                                .clipShape(RoundedRectangle(cornerRadius: 40))
                                            
                                            Text(item.title)
                                                .font(.system(size: min(geometry.size.width * 0.07, 45), design: .serif))
                                                .italic()
                                                .padding(.top, 10)
                                        }
                                    }
                                    .buttonStyle(PlainButtonStyle())
                                }
                            }
                            .padding(.horizontal, geometry.size.width * 0.05)
                            .padding(.top, 20)
                            .padding(.bottom, geometry.safeAreaInsets.bottom + 20)
                        }
                    }
                }
            }
            .navigationBarHidden(true)
        }
        .navigationViewStyle(.stack)
    }
}

// MARK: - Model with destination views
struct ContentItem: Identifiable {
    let id = UUID()
    let title: String
    let imageName: String
    let destination: AnyView
}

let contentData: [ContentItem] = [
    .init(title: "Leftover Ideas", imageName: "leftover", destination: AnyView(LeftoverIdeas())),
    .init(title: "Party Notes", imageName: "notes", destination: AnyView(PartyNotesView())),
    .init(title: "Grocery List", imageName: "shopping", destination: AnyView(GroceryListView()))
]

// MARK: - Preview
struct MorePageView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            MorePageView()
                .previewDevice("iPhone 16 Pro")
        }
    }
}



