import SwiftUI

struct homepage: View {
    @State var eventlist = [GetEventDatum]()

    var body: some View {
        NavigationStack {
            GeometryReader { geometry in
                VStack(spacing: 0) {

                    // Top Bar
                    HStack {
                        Text("Home Page")
                            .font(.system(size: geometry.size.width * 0.08))
                            .foregroundColor(Color.purple.opacity(0.8))
                            .padding(.leading, geometry.size.width * 0.04)

                        Spacer()

                        NavigationLink(destination: SettingsView()) {
                            VStack(spacing: 2) {
                                Image(systemName: "gearshape.fill")
                                    .resizable()
                                    .frame(width: geometry.size.width * 0.08, height: geometry.size.width * 0.08)
                                    .foregroundColor(.black)
                                Text("Settings")
                                    .font(.system(size: geometry.size.width * 0.05))
                                    .foregroundColor(.black)
                            }
                        }
                        .padding(.trailing, geometry.size.width * 0.04)
                    }
                    .padding(.top, geometry.size.height * 0.02)
                    .padding(.bottom, geometry.size.height * 0.01)

                    // List of Events with swipe-to-delete
                    List {
                        ForEach(eventlist) { event in
                            VStack(spacing: 0) {
                                EventCardView(event: event)
                                    .padding(.vertical, 8)
                            }
                            .listRowInsets(EdgeInsets())
                            .listRowBackground(Color.clear)
                        }
                        .onDelete(perform: deleteItems)
                    }


                    .listStyle(PlainListStyle())
                    .scrollContentBackground(.hidden) // For iOS 16+
                    .background(Color.white)

                    Spacer()

                    // Bottom Bar
                    HStack(spacing: 0) {
                        ForEach(BarButton.allCases, id: \.self) { type in
                            NavigationLink(destination: type.destinationView) {
                                VStack(spacing: 2) {
                                    Image(systemName: type.iconName)
                                        .font(.system(size: geometry.size.width * 0.08))
                                        .foregroundColor(.black)
                                    Text(type.title)
                                        .font(.system(size: geometry.size.width * 0.028, weight: .regular, design: .serif))
                                        .italic()
                                        .foregroundColor(.black)
                                }
                                .frame(maxWidth: .infinity)
                            }

                            if type != .more {
                                Spacer(minLength: 0)
                            }
                        }
                    }
                    .padding(.horizontal, geometry.size.width * 0.04)
                    .padding(.vertical, geometry.size.height * 0.015)
                    .background(Color(red: 0.7, green: 0.6, blue: 0.95))
                    .cornerRadius(geometry.size.height * 0.04)
                    .padding(.horizontal, geometry.size.width * 0.02)
                    .padding(.bottom, geometry.size.height * 0.01)
                }
                .frame(width: geometry.size.width, height: geometry.size.height)
                .onAppear {
                    getEvent()
                }
            }
            .edgesIgnoringSafeArea(.bottom)
            .navigationBarHidden(true)
        }
    }

    // MARK: - Fetch Events
    func getEvent() {
        let email = Manager.shared.email
        let url = APIList.geteventUrl + "?email=\(email)"

        APIHandler.shared.getAPIValues(type: GetEvent.self, apiUrl: url, method: "POST") { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    print("API Response: \(response)")
                    eventlist = response.data
                case .failure(let err):
                    print("API Error: \(err)")
                }
            }
        }
    }

    // MARK: - Delete Event from Server
    func deleteEventFromServer(eventID: String, completion: @escaping (Bool) -> Void) {
        guard let url = URL(string: "http://localhost/planora/delete_event.php") else {
            print("Invalid URL")
            completion(false)
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"

        let boundary = UUID().uuidString
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        var body = Data()
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"eventId\"\r\n\r\n".data(using: .utf8)!)
        body.append("\(eventID)\r\n".data(using: .utf8)!)
        body.append("--\(boundary)--\r\n".data(using: .utf8)!)

        request.httpBody = body

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Delete API error:", error.localizedDescription)
                completion(false)
                return
            }

            guard let data = data else {
                print("No data from delete API")
                completion(false)
                return
            }

            if let responseString = String(data: data, encoding: .utf8) {
                print("Delete response:", responseString)
            }

            completion(true)
        }.resume()
    }

    // MARK: - Handle Swipe-to-Delete
    func deleteItems(at offsets: IndexSet) {
        for index in offsets {
            let event = eventlist[index]
            deleteEventFromServer(eventID: String(event.id)) { success in
                if success {
                    DispatchQueue.main.async {
                        eventlist.remove(atOffsets: offsets)
                    }
                }
            }

            }
        }
    }


// MARK: - Card View
struct EventCardView: View {
    let event: GetEventDatum

    var body: some View {
        NavigationLink(destination: PreferenceView()) {
            HStack {
                VStack(alignment: .leading, spacing: 6) {
                    Text(event.eventName)
                        .font(.headline)
                        .foregroundColor(.black)

                    Text(event.eventDate)
                        .font(.subheadline)
                        .foregroundColor(.gray)
                }

                Spacer()

                Image(systemName: "chevron.right")
                    .foregroundColor(.black)
            }
            .padding()
            .frame(maxWidth: .infinity)
            .background(
                LinearGradient(
                    gradient: Gradient(colors: [Color.pink.opacity(0.3), Color.purple.opacity(0.5)]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .cornerRadius(16)
            .shadow(color: Color.black.opacity(0.1), radius: 4, x: 0, y: 2)
            .padding(.horizontal)
        }
    }
}

// MARK: - Bottom Bar Enum
enum BarButton: CaseIterable {
    case createEvent, home, more

    var iconName: String {
        switch self {
        case .createEvent: return "pencil"
        case .home: return "house"
        case .more: return "message.fill"
        }
    }

    var title: String {
        switch self {
        case .createEvent: return "create event"
        case .home: return "Home"
        case .more: return "more"
        }
    }

    @ViewBuilder
    var destinationView: some View {
        switch self {
        case .createEvent: CreateEventView()
        case .home: homepage()
        case .more: MoreView()
        }
    }
}

// MARK: - Preview
struct homepage_Previews: PreviewProvider {
    static var previews: some View {
        homepage()
    }
}

