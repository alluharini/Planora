import SwiftUI

struct BudgetView: View {
    let selectedDishes: [AIfooddRecommended]
    let selectedMandatory: Set<String>
    let guestAllocations: [AIfooddRecommended: Int]
    let totalGuests: String
    let priceLevel: String
    
    @State private var isSaved = false
    @State private var navigateToHome = false
    @State private var showPreferenceView = false
    
    @Environment(\.presentationMode) var presentationMode
    
    let mandatoryPricesByLevel: [String: [String: Int]] = [
            "basic": [
                "Plain Rice": 8, "Chapati": 6, "Salad": 4, "Papad": 3, "Curd": 5,
                "Pickle": 2, "Ice Cream": 10, "Sweet": 8, "Gulab Jamun": 8,
                "Samosa": 7, "Cold Drink": 5, "Juice": 7, "Chips": 3, "Pani Puri": 7
            ],
            "medium": [
                "Plain Rice": 12, "Chapati": 10, "Salad": 6, "Papad": 5, "Curd": 8,
                "Pickle": 4, "Ice Cream": 15, "Sweet": 12, "Gulab Jamun": 12,
                "Samosa": 10, "Cold Drink": 8, "Juice": 10, "Chips": 5, "Pani Puri": 10
            ],
            "premium": [
                "Plain Rice": 20, "Chapati": 18, "Salad": 12, "Papad": 10, "Curd": 15,
                "Pickle": 8, "Ice Cream": 25, "Sweet": 22, "Gulab Jamun": 22,
                "Samosa": 18, "Cold Drink": 15, "Juice": 18, "Chips": 10, "Pani Puri": 18
            ]
        ]

    var totalCost: Int {
        guard let guests = Int(totalGuests) else { return 0 }
        var cost = 0
        
        // Calculate cost for selected dishes
        for (dish, count) in guestAllocations {
            cost += count * dish.price
        }
        
        // Calculate cost for mandatory items
        for item in selectedMandatory {
            if let price = mandatoryPricesByLevel[priceLevel]?[item.capitalized] {
                cost += guests * price
            }
        }
        
        return cost
    }
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text("💰 Budget Breakdown")
                    .font(.title)
                    .bold()
                
                VStack(alignment: .leading, spacing: 15) {
                    Text("Selected Dishes")
                        .font(.headline)
                    
                    ForEach(selectedDishes, id: \.name) { dish in
                        let count = guestAllocations[dish] ?? 0
                        HStack {
                            Text(dish.name)
                            Spacer()
                            Text("\(count) × ₹\(dish.price) = ₹\(count * dish.price)")
                        }
                    }
                }
                
                if !selectedMandatory.isEmpty {
                    VStack(alignment: .leading, spacing: 15) {
                        Text("Mandatory Items")
                            .font(.headline)
                        
                        ForEach(Array(selectedMandatory), id: \.self) { item in
                            let guests = Int(totalGuests) ?? 0
                            let price = mandatoryPricesByLevel[priceLevel]?[item.capitalized] ?? 0
                            HStack {
                                Text(item.capitalized)
                                Spacer()
                                Text("\(guests) × ₹\(price) = ₹\(guests * price)")
                            }
                        }
                    }
                }
                
                Divider()
                
                HStack {
                    Text("Total Cost")
                        .font(.title2)
                        .bold()
                    Spacer()
                    Text("₹\(totalCost)")
                        .font(.title2)
                        .bold()
                }
                
                VStack(alignment: .leading, spacing: 10) {
                    Text("Cost per Guest")
                        .font(.headline)
                    if let guests = Int(totalGuests), guests > 0 {
                        Text("₹\(totalCost / guests)")
                            .font(.title3)
                    }
                }
                .padding(.top)
                
                // Action Buttons
                VStack(spacing: 15) {
                    Button(action: {
                        isSaved = true
                        // Save the budget data using BudgetManager
                        BudgetManager.shared.saveBudgetData(
                            selectedDishes: selectedDishes,
                            selectedMandatory: selectedMandatory,
                            guestAllocations: guestAllocations
                        )
                        UserDefaults.standard.set(true, forKey: "hasSavedBudget")
                        
                        // Navigate to HomePageView
                        navigateToHome = true
                        // updateEvent()  // uncomment if needed
                    }) {
                        HStack {
                            Image(systemName: "house")
                            Text("go back to home")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                    
                    Button(action: {
                        showPreferenceView = true
                    }) {
                        HStack {
                            Image(systemName: "pencil")
                            Text("Modify Preferences")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                    .fullScreenCover(isPresented: $showPreferenceView) {
                        PreferenceView()
                    }
                }
                .padding(.top, 20)
            }
            .padding()
        }
        .navigationTitle("Budget Summary")
        .navigationBarBackButtonHidden(true)  // Hide default back button
        
        // Hidden NavigationLink for programmatic navigation to home
        NavigationLink(destination: homepage(), isActive: $navigateToHome) {
            EmptyView()
        }
    }
    
    func updateEvent() {
        var form: [String: String] = [
            "id": Manager.shared.eventID,
            "status": "1",
        ]
        
        APIHandler.shared.postAPIValues(type: UpdateEvent.self, apiUrl: APIList.updateeventUrl, method: "POST", formData: form) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    print("API Response: \(response)")
                case .failure(let err):
                    print("API Error: \(err)")
                }
            }
        }
    }
}

struct BudgetView_Previews: PreviewProvider {
    static var previews: some View {
        BudgetView(
            selectedDishes: [],
            selectedMandatory: [],
            guestAllocations: [:],
            totalGuests: "10",
            priceLevel: "medium"
        )
    }
}

