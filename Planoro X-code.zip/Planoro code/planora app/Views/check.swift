//import SwiftUI
//
//struct DishSelectionView: View {
//    let totalGuests: String
//    let selectedCuisine: String
//    let selectedDietary: String
//    let selectedPriceLevel: String
//    let selectedEventType: String
//
//    @State private var selectedDishes: [Dish] = []
//    @State private var guestAllocations: [UUID: String] = [:]
//    @State private var addMandatory = false
//    @State private var selectedMandatory: [Dish] = []
//    @State private var recommendedDishes: [Dish] = []
//
//    private let allDishes: [Dish] = Dish.generateMockData(count: 600)
//
//    private var priceRange: ClosedRange<Int> {
//        switch selectedPriceLevel {
//        case "basic": return 10...50
//        case "medium": return 51...90
//        case "premium": return 91...130
//        default: return 10...30
//        }
//    }
//
//    private var mandatoryOptions: [Dish] {
//        let keywords = ["ice cream", "salad", "drink", "roll", "cake", "soup", "sweet"]
//        var seen = Set<String>()
//        var result: [Dish] = []
//        for dish in allDishes where keywords.contains(where: dish.name.lowercased().contains) {
//            if seen.insert(dish.name).inserted {
//                result.append(dish)
//            }
//            if result.count == 20 { break }
//        }
//        return result
//    }
//
//    var body: some View {
//        ScrollView {
//            VStack(alignment: .leading, spacing: 10) {
//                Text("✅ Recommended Dishes:")
//                    .font(.headline)
//
//                ForEach(recommendedDishes) { dish in
//                    DishRow(
//                        dish: dish,
//                        isSelected: selectedDishes.contains(where: { $0.id == dish.id }),
//                        toggleSelection: {
//                            if let index = selectedDishes.firstIndex(where: { $0.id == dish.id }) {
//                                selectedDishes.remove(at: index)
//                                guestAllocations[dish.id] = nil
//                            } else {
//                                selectedDishes.append(dish)
//                            }
//                        }
//                    )
//                }
//
//                if !selectedDishes.isEmpty {
//                    Text("👥 Guest Allocation")
//                        .font(.headline)
//
//                    let remaining = (Int(totalGuests) ?? 0) - guestAllocations.values.compactMap { Int($0) }.reduce(0, +)
//                    Text("Remaining guests to assign: \(remaining)")
//
//                    ForEach(selectedDishes) { dish in
//                        HStack {
//                            Text(dish.name)
//                            Spacer()
//                            TextField("Guests", text: Binding(
//                                get: { guestAllocations[dish.id] ?? "0" },
//                                set: { newValue in
//                                    let newInt = Int(newValue) ?? 0
//                                    let otherTotal = guestAllocations
//                                        .filter { $0.key != dish.id }
//                                        .values.compactMap { Int($0) }
//                                        .reduce(0, +)
//                                    if newInt + otherTotal <= (Int(totalGuests) ?? 0) {
//                                        guestAllocations[dish.id] = newValue
//                                    }
//                                }
//                            ))
//                            .keyboardType(.numberPad)
//                            .frame(width: 60)
//                            .textFieldStyle(RoundedBorderTextFieldStyle())
//                        }
//                    }
//
//                    Toggle("Add mandatory dishes for all guests?", isOn: $addMandatory)
//
//                    if addMandatory {
//                        VStack(alignment: .leading) {
//                            Text("🍰 Choose Mandatory Dishes:")
//                                .font(.headline)
//                            ForEach(mandatoryOptions) { dish in
//                                HStack {
//                                    Text("\(dish.name) - ₹\(dish.price)")
//                                    Spacer()
//                                    Button(action: {
//                                        if let index = selectedMandatory.firstIndex(where: { $0.id == dish.id }) {
//                                            selectedMandatory.remove(at: index)
//                                        } else {
//                                            selectedMandatory.append(dish)
//                                        }
//                                    }) {
//                                        Image(systemName: selectedMandatory.contains(where: { $0.id == dish.id }) ? "checkmark.circle.fill" : "circle")
//                                    }
//                                }
//                            }
//                        }
//                    }
//
//                    NavigationLink(destination: BudgetView(
//                        selectedDishes: selectedDishes,
//                        selectedMandatory: selectedMandatory,
//                        guestAllocations: guestAllocations,
//                        totalGuests: totalGuests
//                    )) {
//                        Text("View Budget")
//                            .frame(maxWidth: .infinity)
//                            .padding()
//                            .background(Color.blue)
//                            .foregroundColor(.white)
//                            .cornerRadius(10)
//                    }
//                }
//            }
//            .padding()
//        }
//        .navigationTitle("Select Dishes")
//        .onAppear {
//            recommendedDishes = allDishes.filter {
//                $0.cuisine.lowercased() == selectedCuisine.lowercased() &&
//                $0.dietary == selectedDietary &&
//                priceRange.contains($0.price)
//            }.prefix(10).map { $0 }
//        }
//    }
//}
//
//struct DishRow: View {
//    let dish: Dish
//    let isSelected: Bool
//    let toggleSelection: () -> Void
//
//    var body: some View {
//        HStack {
//            VStack(alignment: .leading) {
//                Text(dish.name)
//                Text("\(dish.cuisine), ₹\(dish.price)")
//                    .font(.caption)
//                    .foregroundColor(.gray)
//            }
//            Spacer()
//            Button(action: toggleSelection) {
//                Image(systemName: isSelected ? "checkmark.circle.fill" : "circle")
//            }
//        }
//    }
//}
//
//// MARK: - Mock Dish Data Generator
//
//extension Dish {
//    static func generateMockData(count: Int) -> [Dish] {
//        let names = ["Biryani", "Ice Cream", "Salad", "Sushi", "Pasta", "Pizza", "Soup", "Burger", "Stew", "Rolls", "Cake", "Noodles"]
//        let adjectives = ["Spicy", "Tasty", "Grilled", "Crispy", "Fried", "Cold", "Hot", "Sweet"]
//        let cuisines = ["American", "Chinese", "French", "Indian", "Italian", "Japanese", "Mexican", "Thai", "Mediterranean", "Korean", "Spanish"]
//        let dietaryOptions = ["vegetarian", "non-vegetarian", "vegan", "gluten-free", "halal", "kosher"]
//
//        var dishes: [Dish] = []
//        for _ in 0..<count {
//            let name = "\(adjectives.randomElement()!) \(names.randomElement()!)"
//            let cuisine = cuisines.randomElement()!
//            let dietary = dietaryOptions.randomElement()!
//            let price = Int.random(in: 10...100)
//            dishes.append(Dish(name: name, cuisine: cuisine, dietary: dietary, price: price))
//        }
//        return dishes
//    }
//}
//
//struct DishSelectionView_Previews: PreviewProvider {
//    static var previews: some View {
//        DishSelectionView(
//            totalGuests: "10",
//            selectedCuisine: "Indian",
//            selectedDietary: "vegetarian",
//            selectedPriceLevel: "medium",
//            selectedEventType: "Birthday"
//        )
//    }
//}
//
//
//
