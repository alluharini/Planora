//
//  planora_appTests.swift
//  planora appTests
//
//  Created by SAIL on 05/05/25.
//

import Testing
@testable import planora_app

struct planora_appTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
