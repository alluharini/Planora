#python
from flask import Flask, request, jsonify
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
import traceback

app = Flask(__name__)

# Load dataset
df = pd.read_csv("food_dataset.csv")

# Prepare features and target
features = ['cuisine', 'dietary_preference', 'event_type', 'expensive_level']
target = 'dish_name'  # We will predict dish_name based on inputs

# Encode categorical variables
encoders = {}
for column in features + [target]:
    enc = LabelEncoder()
    df[column] = enc.fit_transform(df[column])
    encoders[column] = enc

# Train the model
X = df[features]
y = df[target]
model = RandomForestClassifier()
model.fit(X, y)

# Helper function to encode input using saved encoders
def encode_input(data):
    encoded = {}
    for feature in features:
        value = data.get(feature)
        if value is None:
            raise ValueError(f"Missing value for: {feature}")
        encoder = encoders[feature]
        if value not in encoder.classes_:
            return None  # Unknown value
        encoded[feature] = encoder.transform([value])[0]
    return encoded

@app.route("/recommend_food", methods=["POST"])
def recommend_food():
    try:
        # Access form data instead of JSON
        input_data = {
            'cuisine': request.form.get('cuisine'),
            'dietary_preference': request.form.get('dietary_preference'),
            'event_type': request.form.get('event_type'),
            'expensive_level': request.form.get('expensive_level')
        }

        # Ensure all data is present
        if None in input_data.values():
            return jsonify({
                "status": False,
                "message": "Missing one or more required parameters.",
                "data": []
            }), 400

        # Encode input
        encoded_input = encode_input(input_data)
        if encoded_input is None:
            return jsonify({
                "status": False,
                "message": "Invalid input. Please provide correct values.",
                "data": []
            }), 400

        # Predict
        X_input = [[encoded_input[feature] for feature in features]]
        prediction_encoded = model.predict(X_input)[0]
        prediction = encoders[target].inverse_transform([prediction_encoded])[0]

        return jsonify({
            "status": True,
            "message": "Food recommendation successful.",
            "data": [prediction]
        })

    except Exception as e:
        return jsonify({
            "status": False,
            "message": f"Error: {str(e)}",
            "data": []
        }), 500

if __name__ == "__main__":
    app.run(debug=True)
