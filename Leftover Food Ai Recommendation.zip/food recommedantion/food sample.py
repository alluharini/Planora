import csv

def load_dishes():
    dishes = [
        {"name": "Chicken Biryani", "cuisine": "indian", "diet": "non-vegetarian", "price": 50},
        {"name": "Paneer Butter Masala", "cuisine": "indian", "diet": "vegetarian", "price": 40},
        {"name": "Tofu Stir Fry", "cuisine": "chinese", "diet": "vegan", "price": 30},
        {"name": "Veg Noodles", "cuisine": "chinese", "diet": "vegetarian", "price": 25},
        {"name": "Grilled Salmon", "cuisine": "continental", "diet": "non-vegetarian", "price": 60},
        {"name": "Caesar Salad", "cuisine": "continental", "diet": "vegetarian", "price": 35},
        {"name": "Dal Makhani", "cuisine": "indian", "diet": "vegetarian", "price": 30},
        {"name": "Sushi Rolls", "cuisine": "japanese", "diet": "non-vegetarian", "price": 70},
        {"name": "Veg Momo", "cuisine": "chinese", "diet": "vegetarian", "price": 20},
        {"name": "Spring Rolls", "cuisine": "chinese", "diet": "vegan", "price": 20},
    ]
    return dishes

def filter_dishes(preferences, dishes):
    cuisines = [c.strip().lower() for c in preferences["cuisines"]]
    diet = preferences["diet"].lower()
    price_level = preferences.get("price_level", None)

    filtered_dishes = [
        dish for dish in dishes
        if dish["cuisine"] in cuisines and (
            dish["diet"] == diet or (diet == "vegetarian" and dish["diet"] == "vegan")
        )
    ]

    if price_level:
        if price_level == 'low':
            filtered_dishes = [dish for dish in filtered_dishes if dish["price"] <= 30]
        elif price_level == 'medium':
            filtered_dishes = [dish for dish in filtered_dishes if 30 < dish["price"] <= 50]
        elif price_level == 'high':
            filtered_dishes = [dish for dish in filtered_dishes if dish["price"] > 50]

    return filtered_dishes

def get_preference_input():
    cuisine_input = input("Enter preferred cuisines (comma-separated): ")
    diet_input = input("Enter dietary preference (vegetarian / non-vegetarian / vegan): ")
    price_input = input("Enter price level (low/medium/high): ").strip().lower()

    return {
        "cuisines": [c.strip() for c in cuisine_input.split(",")],
        "diet": diet_input.strip(),
        "price_level": price_input if price_input in ['low', 'medium', 'high'] else None
    }

def prompt_allocation(dishes, total_guests):
    allocation = {}
    remaining = total_guests

    print("\n--- Guest Allocation ---")
    for dish in dishes:
        while True:
            try:
                print(f"Remaining guests to assign: {remaining}")
                count = int(input(f"How many guests should be served '{dish['name']}'? "))
                if count < 0 or count > remaining:
                    print(f"⚠️ You can assign up to {remaining} guests.")
                else:
                    allocation[dish["name"]] = count
                    remaining -= count
                    break
            except ValueError:
                print("❌ Please enter a valid number.")
    return allocation, remaining

def prompt_allocation_again(dishes, guests_remaining, allocation):
    print("\n🔁 Reassign guests to any dish below:")

    available_dishes = [dish for dish in dishes if dish["name"] not in allocation]
    
    if not available_dishes:
        print("No more dishes available for assignment.")
        return guests_remaining

    while guests_remaining > 0 and available_dishes:
        print(f"\nRemaining guests: {guests_remaining}")
        for i, dish in enumerate(available_dishes, 1):
            print(f"{i}. {dish['name']}")

        try:
            choice = int(input("Select a dish number to assign guests to (0 to stop): "))
            if choice == 0:
                break
            if choice < 1 or choice > len(available_dishes):
                print("Invalid dish number. Try again.")
                continue

            selected_dish = available_dishes[choice - 1]
            count = int(input(f"How many guests to assign to {selected_dish['name']}? "))
            if count < 0 or count > guests_remaining:
                print(f"⚠️ You can assign up to {guests_remaining} guests.")
                continue

            allocation[selected_dish["name"]] = allocation.get(selected_dish["name"], 0) + count
            guests_remaining -= count

            # Update available dishes to reflect newly assigned dish
            available_dishes = [dish for dish in dishes if dish["name"] not in allocation]

        except ValueError:
            print("Please enter valid numbers.")
    return guests_remaining

def calculate_cost(allocation, dishes):
    cost = 0
    print("\n--- Cost Breakdown ---")
    for dish_name, count in allocation.items():
        dish = next((d for d in dishes if d["name"] == dish_name), None)
        if dish:
            dish_cost = count * dish["price"]
            print(f"{dish_name}: {count} guests x ₹{dish['price']} = ₹{dish_cost}")
            cost += dish_cost
    print(f"\nTotal Cost: ₹{cost}")

def main():
    print("🍽️ Event Dish Recommender\n")
    dishes = load_dishes()

    try:
        total_guests = int(input("Enter total number of guests: "))
        if total_guests <= 0:
            print("Total guests should be greater than 0.")
            return
    except ValueError:
        print("Invalid number of guests.")
        return

    preferences = get_preference_input()

    recommended = filter_dishes(preferences, dishes)

    if not recommended:
        print("❌ No dishes match the selected preferences.")
        return

    print("\n✅ Recommended Dishes:")
    for dish in recommended:
        print(f"- {dish['name']} ({dish['cuisine'].capitalize()}, {dish['diet']}) - ₹{dish['price']}")

    allocation, remaining = prompt_allocation(recommended, total_guests)

    print(f"\nTotal guests allocated: {total_guests - remaining} / {total_guests}")
    if remaining > 0:
        print(f"\n⚠️ {remaining} guests unassigned!")
        choice = input("Do you want to assign remaining guests to any dish again? (yes/no): ").strip().lower()
        if choice == "yes":
            remaining = prompt_allocation_again(recommended, remaining, allocation)

    if remaining > 0:
        print(f"\n⚠️ {remaining} guests remain unassigned. Proceeding with cost calculation for assigned guests only.")

    calculate_cost(allocation, recommended)

    # Ask for new preferences if no dishes are left to assign
    if remaining > 0 and not recommended:
        print("🔁 No dishes left, let's try new preferences.")
        preferences = get_preference_input()
        recommended = filter_dishes(preferences, dishes)
        if recommended:
            allocation, remaining = prompt_allocation(recommended, total_guests)
            if remaining == 0:
                calculate_cost(allocation, recommended)
            else:
                print(f"⚠️ {remaining} guests remain unassigned.")

if __name__ == "__main__":
    main()
