from flask import Flask, request, jsonify
import pandas as pd
import traceback

app = Flask(__name__)

# Load dataset
df = pd.read_csv("food_dataset.csv")

# Helper function to filter dishes based on ingredients
def get_matching_dishes(ingredient):
    # Filter the dataframe for dishes that contain the given ingredient
    matching_dishes = df[df['ingredients'].str.lower().apply(lambda x: ingredient.lower() in x)]
    
    # Debugging: Print matching dishes
    print(f"Matching dishes based on ingredient '{ingredient}': {matching_dishes}")
    
    return matching_dishes

@app.route("/recommend_food", methods=["POST"])
def recommend_food():
    try:
        # Access form data for ingredients
        ingredient_input = request.form.get('ingredient')

        # Ensure ingredient data is present
        if not ingredient_input:
            return jsonify({
                "status": False,
                "message": "Missing ingredient parameter.",
                "data": []
            }), 400

        # Get matching dishes
        matching_dishes = get_matching_dishes(ingredient_input)

        # Check if there are any matching dishes
        if matching_dishes.empty:
            return jsonify({
                "status": False,
                "message": f"No matching dishes found for the ingredient '{ingredient_input}'.",
                "data": []
            }), 404

        # Return dish names
        recommended_dishes = matching_dishes['dish_name'].tolist()

        return jsonify({
            "status": True,
            "message": "Food recommendation successful.",
            "data": recommended_dishes
        })

    except Exception as e:
        return jsonify({
            "status": False,
            "message": f"Error: {str(e)}",
            "data": []
        }), 500

if __name__ == "__main__":
    app.run(debug=True)
