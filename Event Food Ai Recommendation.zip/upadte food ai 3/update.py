import random

# Simulated dataset
all_dishes = []
cuisines = ['American', 'Chinese', 'French', 'Indian', 'Italian', 'Japanese', 'Mexican', 'Thai']
dietary_options = ['Vegetarian', 'Non-Vegetarian', 'Vegan']
price_levels = {
    'basic': (10, 30),
    'medium': (31, 60),
    'premium': (61, 100)
}

# Generate dummy dish data
for _ in range(600):
    name = f"{random.choice(['Spicy', 'Tasty', 'Grilled', 'Crispy', 'Fried', 'Cold', 'Hot', 'Sweet'])} {random.choice(['Biryani', 'Ice Cream', 'Salad', 'Sushi', 'Pasta', 'Pizza', 'Soup', 'Burger', 'Stew', 'Rolls', 'Cake', 'Noodles'])}"
    cuisine = random.choice(cuisines)
    dietary = random.choice([opt.lower() for opt in dietary_options])
    price = random.randint(10, 100)
    all_dishes.append({'name': name, 'cuisine': cuisine, 'dietary': dietary, 'price': price})

# 🍽️ Event Dish Recommender
print("🍽️ Event Dish Recommender")
total_guests = int(input("\nEnter total number of guests: "))

# Show available options
print("\n📌 Available Cuisines:")
for c in cuisines:
    print(f"- {c}")
cuisine_input = input("Enter preferred cuisine from above: ").strip().capitalize()

print("\n📌 Available Dietary Preferences:")
for d in dietary_options:
    print(f"- {d}")
dietary_input = input("Enter dietary preference (e.g., Vegetarian, Non-Vegetarian, Vegan): ").strip().lower()

price_level = input("Enter price level (basic / medium / premium): ").strip().lower()
min_price, max_price = price_levels.get(price_level, (10, 30))

# Filter matching dishes
filtered_dishes = [
    dish for dish in all_dishes
    if dish['cuisine'].lower() == cuisine_input.lower()
    and dish['dietary'] == dietary_input
    and min_price <= dish['price'] <= max_price
]

print("\n✅ Recommended Dishes:")
for idx, dish in enumerate(filtered_dishes[:10], 1):
    print(f"{idx}. {dish['name']} ({dish['cuisine']}, {dish['dietary']}) - ₹{dish['price']}")

selected_indexes = input("\nEnter the numbers of the dishes you want to include (comma-separated): ").split(",")
selected_dishes = [filtered_dishes[int(i.strip()) - 1] for i in selected_indexes if i.strip().isdigit()]

# Guest Allocation
print("\n--- Guest Allocation ---")
remaining_guests = total_guests
allocation = {}

for dish in selected_dishes:
    while True:
        print(f"Remaining guests to assign: {remaining_guests}")
        try:
            count = int(input(f"How many guests should be served '{dish['name']}'? "))
            if 0 <= count <= remaining_guests:
                allocation[dish['name']] = {'count': count, 'price': dish['price']}
                remaining_guests -= count
                break
            else:
                print("Please enter a valid number within the remaining guests.")
        except ValueError:
            print("Please enter a valid number.")

# Optional: Add mandatory dishes for all guests
mandatory_dishes = []
ask_mandatory = input("\nWould you like to add some mandatory dishes for all guests? (yes/no): ").strip().lower()
if ask_mandatory == "yes":
    # Curated mandatory options (filter from dataset)
    common_keywords = ['ice cream', 'salad', 'drink', 'roll', 'cake', 'soup', 'sweet']
    mandatory_pool = [dish for dish in all_dishes if any(k in dish['name'].lower() for k in common_keywords)]
    
    # Deduplicate and take only 20
    seen_names = set()
    curated_mandatory = []
    for d in mandatory_pool:
        if d['name'] not in seen_names:
            curated_mandatory.append(d)
            seen_names.add(d['name'])
        if len(curated_mandatory) == 20:
            break

    print("\nHere are some commonly served dishes you may want to add for all guests:\n")
    for idx, dish in enumerate(curated_mandatory, 1):
        print(f"{idx}. {dish['name']} - ₹{dish['price']}")

    selected_mandatory = input("\nEnter the numbers of dishes you want to make mandatory (comma-separated): ").split(",")
    for idx in selected_mandatory:
        if idx.strip().isdigit():
            dish = curated_mandatory[int(idx.strip()) - 1]
            mandatory_dishes.append(dish)

# Final Cost Calculation
print("\n--- Cost Breakdown ---")
total_cost = 0
for dish_name, details in allocation.items():
    cost = details['count'] * details['price']
    total_cost += cost
    print(f"{dish_name}: {details['count']} guests x ₹{details['price']} = ₹{cost}")

for dish in mandatory_dishes:
    cost = total_guests * dish['price']
    total_cost += cost
    print(f"{dish['name']} (mandatory): {total_guests} guests x ₹{dish['price']} = ₹{cost}")

print(f"\nTotal Cost: ₹{total_cost}")
